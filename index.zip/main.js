
const modal = document.querySelector(".info-section")
const form = document.querySelector("form")

form.addEventListener("submit",(e)=>{
    e.preventDefault()
})

function toggle(){
    console.log("asd")
    modal.classList.toggle("show")
}

